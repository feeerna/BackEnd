import { Estudiante } from "./estudiante";
import recorrerEstudiantes from "./recorrerEstudiantes";
import { insertarEstudiante, actualizarEstudiante, borrarEstudiante } from "./operaciones";


//Definiendo objetos(Literal) estudiante

const estudiante1: Estudiante = {
    nombre: "Fernanda",
    apellido: "Astaiza",
    edad: 17,
    tipoIdentificacion: "TI",
    numeroIdentificacion: 123456
}

const estudiante2: Estudiante = {
    nombre: "Yulieth",
    apellido: "Bolaños",
    edad: 18,
    tipoIdentificacion: "CC",
    numeroIdentificacion: "34567"
}

const estudiante3: Estudiante = {
    nombre: "Juan",
    apellido: "Pérez",
    tipoIdentificacion: "CC",
    numeroIdentificacion: 56789
}

const estudiante4: Estudiante = {
    nombre: "Laura",
    apellido: "Lopez",
    tipoIdentificacion: "CC",
    numeroIdentificacion: 56789
}

//Crear arreglo de estudiantes
const listaEstudiante : Estudiante [] = [
    estudiante1, 
    estudiante2,
    estudiante3,
    estudiante4
]

//recorrer el arreglo
recorrerEstudiantes(listaEstudiante)

//Operaciones con arreglos
console.log("--------------------------")
console.log("Antes de insertar")
console.log(listaEstudiante)
insertarEstudiante(estudiante1, listaEstudiante)
console.log("---------------------")
console.log("Despues de insertar")
console.log(listaEstudiante)

/*actualizarEstudiante(1, listaEstudiante, "Pablo", "Suarez")
console.log(listaEstudiante)*/

console.log("--------------------------")
console.log("Antes de eliminar")
console.log(listaEstudiante)
borrarEstudiante(4, listaEstudiante)
console.log("--------------------------")
console.log("Despues de eliminar")
console.log(listaEstudiante)