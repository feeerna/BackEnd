import { Estudiante } from "./estudiante";


/*Funcion declaracion
function recorrerEstudiantes(arregloEstudiantes: Estudiante[]){
    arregloEstudiantes.forEach(function(elemento){
        console.log(elemento)
        console.log("--------------------")
    });
}*/

/*Funcion expresion
const recorrerEstudiantes = function(arregloEstudiantes: Estudiante[]){
    arregloEstudiantes.forEach(function(elemento){
        console.log(elemento)
        console.log("--------------------")
    });
}*/

//Funcion flecha
const recorrerEstudiantes = (arregloEstudiantes: Estudiante[]) => {
    arregloEstudiantes.forEach(function(elemento){
        console.log(elemento)
        console.log("--------------------")
    });
}

export default recorrerEstudiantes;