import { Estudiante } from "./estudiante"

export const insertarEstudiante = function (estudiante:Estudiante, arregloEstudiantes: Estudiante[]){
    arregloEstudiantes.push(estudiante)
}

export const actualizarEstudiante = function( indice : number, nombre: string, apellido: string, listaEstudiante: Estudiante[]){
     
}

export const borrarEstudiante = function(indice: number, listaEstudiante: Estudiante[]){
    listaEstudiante.splice(indice, 1)
}